select Cartoon.voice
from Cartoon
where lower(Cartoon.title) = 'little mermaid'