select name, birthDate
from Moviestar 
where moviestar.name in(select starname
                        from starsIn 
                        where movieyear = 1980 or movietitle like ('% and %') or movietitle like ('% of %')
                        )
order by birthdate desc;