select name , address
from movieExec
where networth >= 10000000;