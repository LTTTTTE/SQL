select year , length
from movie
where lower(title) = 'coal miner''s daughter'