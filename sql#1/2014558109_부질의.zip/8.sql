select name
from movieExec
where certno in ( select presno
                  from studio
                  where lower(name) = 'fox' );