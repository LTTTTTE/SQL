select address , birthDate
from moviestar
where lower(name) = 'alfred molina'