select name
from movieExec
where networth > (select networth
                  from movieExec
                  where lower(name) = 'merv griffin');