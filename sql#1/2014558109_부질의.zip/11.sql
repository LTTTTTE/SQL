select name , address
from movieExec
minus
select movieExec.name , movieExec.address
from movieExec , movieExec movieExec2
where movieExec.networth < movieExec2.networth;