select title , length , MovieExec.name
from movie , movieExec
where (title , year ) in (select movietitle , movieyear
                          from starsin
                          where starname in (select name
                                             from moviestar
                                             where birthDate < '1970-01-01' and lower(address) like '%california%' and gender = 'female'))
and movie.producerno = movieexec.certno
order by length desc ,title;