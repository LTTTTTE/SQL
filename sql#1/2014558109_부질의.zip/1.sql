select address 
from studio 
where lower(name) = 'mgm' OR lower(name) = 'disney'