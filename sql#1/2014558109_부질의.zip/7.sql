select starname, movieyear
from starsin
where (movietitle , movieyear) in(
    select title , year
    from  movie
    where year = 1995 and lower(studioname) = 'mgm');
