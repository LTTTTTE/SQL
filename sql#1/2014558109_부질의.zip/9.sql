select title
from movie
where length > (select length
                from movie
                where lower(title) = 'gone with the wind');